var Foo=function(){};
