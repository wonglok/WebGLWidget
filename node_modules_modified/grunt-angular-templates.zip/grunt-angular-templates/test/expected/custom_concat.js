<h1>One</h1>

<p class="">I am one.</p>

<script type="text/javascript">
  // Test
  /* comments */
  var foo = 'bar';
</script>
