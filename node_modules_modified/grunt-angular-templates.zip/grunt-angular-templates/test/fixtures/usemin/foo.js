/**
 * foo.js
 */

var Foo = function() {};
